# ASP.NET-WebForms-Example<br/>
<code>Español abajo</code><br/><br/>
<b>ENGLISH</b>
<p>ASP.NET Web page example using C# and Web Forms with Master Page. Bootstrap for styles. Put this project here for future reference.<br/>I haven't made web pages with Visual Studio but somebody asked me to for extra $$. :)</p>
<br/>
<br>
<b>Project Features</b>
<br/>
<ul>
	<li>Developed in Visual Studio 2015.</li>
	<li>ASP.NET Web Forms with C#.</li>
	<li>Contact form with required fields, only numbers, only letters, email format validation.</li>
	<li><a href="http://bootswatch.com">Bootswatch.com</a> Bootstrap United theme for main styles.</li>
	<li><a href="https://getbootstrap.com/examples/carousel/">Carousel</a> Template for web page layout.</li>
	<li>Content and images taken from <a href="http://ecuador.travel/">Ecuador.travel</a> for educational purposes only.</li>
</ul>
<b>ESPAÑOL</b>
<p>Ejemplo de página web en ASP con C# usando Web Forms con página master y usando Bootstrap para estilos. Subo este proyecto como referencia futura.<br/>
No había hecho páginas web con Visual Studio pero me lo solicitaron por $$ extra. :)</p>
<br/>
<br>
<b>Características del Proyecto</b>
<br/>
<ul>
	<li>Proyecto realizado en Visual Studio 2015.</li>
	<li>ASP.NET Web Forms con C#.</li>
	<li>Formulario de contacto con validación de campos requeridos, sólo números, sólo texto, formato de correo.</li>
	<li>Tema Bootstrap United de <a href="http://bootswatch.com">Bootswatch.com</a> para estilos principales.</li>
	<li>Plantilla <a href="https://getbootstrap.com/examples/carousel/">Carousel</a> para diagramar la página.</li>
	<li>Contenido y fotos tomado de <a href="http://ecuador.travel/">Ecuador.travel</a> por razones didácticas únicamente.</li>
</ul>	
